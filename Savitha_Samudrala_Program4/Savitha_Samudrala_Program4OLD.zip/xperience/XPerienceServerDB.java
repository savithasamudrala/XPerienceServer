/************************************************
 * Author: Savitha Samudrala
 * Assignment: Program 4
 * Class: CSC 4610
 ************************************************/

package xperience;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import java.io.IOException;
import donabase.DonaBaseException;

public class XPerienceServerDB {

    private static final Logger logger = Logger.getLogger("xperience");

    private final EventStore eventStore;
    private final PasswordList pwList;
    private final ExecutorService executor = Executors.newCachedThreadPool();

    public XPerienceServerDB(EventStore eventStore, PasswordList pwList) {
        this.eventStore = eventStore;
        this.pwList = pwList;
    }

    public void startServer(int port) {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            logger.info("Server started successfully on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                executor.submit(new ClientHandler(clientSocket, eventStore, pwList));
            }
        } catch (IOException e) {
            logger.severe("Server error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        if (args.length != 3) {
            logger.severe("Usage: java XPerienceServerDB <port> <dbServer> <passwordFile>");
            System.exit(1);
        }

        int port = Integer.parseInt(args[0]);
        String dbServer = args[1];
        String passwordFile = args[2];

        try {
            EventStore store = new EventStoreDB(dbServer);
            PasswordList pwList = new PasswordList(passwordFile);
            new XPerienceServerDB(store, pwList).startServer(port);
        } catch (DonaBaseException | IOException e) {
            logger.severe("Initialization failed: " + e.getMessage());
            System.exit(1);
        }
    }
}
