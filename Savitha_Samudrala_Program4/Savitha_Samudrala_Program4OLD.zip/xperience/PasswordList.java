/************************************************
 * Author: Savitha Samudrala
 * Assignment: Program 4
 * Class: CSC 4610
 ************************************************/

package xperience;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/**
 * Class to manage password list
 */
public class PasswordList {
    private final Set<String> passwords;

    /**
     * Create password list from file
     * @param passwordFilePath Path to password file
     * @throws IOException if I/O problem
     */
    public PasswordList(String passwordFilePath) throws IOException {
        passwords = new HashSet<>(Files.readAllLines(Path.of(passwordFilePath)));
    }

    /**
     * If password in list, remove password from list and return true;
     * otherwise (not in list), return false
     * @param password password to use
     * @return true if password in list; false otherwise
     */
    public boolean use(String password) {
        return passwords.remove(password);
    }
}
