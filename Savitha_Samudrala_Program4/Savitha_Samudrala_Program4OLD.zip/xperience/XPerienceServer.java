/************************************************
 * Author: Savitha Samudrala
 * Assignment: Program 4
 * Class: CSC 4610
 ************************************************/

package xperience;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Delegates request handling to a handler class.
 */
public class XPerienceServer {

    private static final Logger logger = Logger.getLogger("xperience");
    private final EventStore eventStore;
    private final PasswordList pwList;
    private final ExecutorService executor = Executors.newCachedThreadPool();

    public XPerienceServer(EventStore eventStore, PasswordList pwList) {
        this.eventStore = eventStore;
        this.pwList = pwList;
    }

    public void startServer(int port) {
        if (port < 1 || port > 65535) {
            logger.severe("Invalid port number: " + port);
            return;
        }

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            logger.info("Server started on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                executor.submit(new ClientHandler(clientSocket, eventStore, pwList));
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Server failed", e);
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java XPerienceServer <port> <passwordFile>");
            System.exit(1);
        }

        int port = Integer.parseInt(args[0]);
        String passwordFile = args[1];

        try {
            PasswordList pwList = new PasswordList(passwordFile);
            EventStore store = new EventStoreMemory();
            new XPerienceServer(store, pwList).startServer(port);
        } catch (IOException e) {
            System.err.println("Could not load password file: " + e.getMessage());
            System.exit(1);
        }
    }
}
