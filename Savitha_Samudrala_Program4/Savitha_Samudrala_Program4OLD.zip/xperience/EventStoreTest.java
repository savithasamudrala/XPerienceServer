package xperience;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.params.provider.Arguments.arguments;

class EventStoreTest {

    private static final String REJECT = "Reject#";
    private static final Charset ENC = StandardCharsets.US_ASCII;
    private static String server;
    private static int port;
    private Socket clntSock;
    private PrintWriter out;

    static void send(String sndStr, PrintWriter out) {
        int half = sndStr.length() / 2;
        out.write(sndStr.substring(0, half));
        out.flush();
        out.write(sndStr.substring(half));
        out.flush();
    }

    static boolean isPrintable(char c) {
        return (c >= 32 && c < 127);
    }

    @BeforeAll
    static void setUp() {
        try {
            server = Objects.requireNonNull(System.getProperty("server"));
            port = Integer.parseInt(System.getProperty("port"));
        } catch (Exception ex) {
            System.err.println("Test setup failed: " + ex);
            throw ex;
        }
    }

    static Stream<Arguments> testInteraction() {
        return Stream.of(
                arguments("Danoke#2025-02-12#20:00#Fusion of Karaoke and Dance#password1#", "Accept#1#"),
                arguments("Dona Dance#2025-02-14#20:00#Dance like you don’t care#password2#", "Accept#2#"),
                arguments("Dona Dance Dance#2025-02-14#21:00#Light the night#password3#", "Accept#3#"),
                arguments("Danoke#2025-02-12#20:00#Fusion of Karaoke and Dance#password4#", REJECT),
                arguments("Dona Dance#2025-03-14#08:00#Dance dance like you don’t care#password5#", REJECT),
                arguments("Dona Dance Dance#2025-03-14#20:00#Light the night#password6#", REJECT),
                arguments("Safety#2025-02-16#20:00#Dance#Leave your friends#password7#", "Accept#4#"),
                arguments("Safety#2025-02-16#20:00#Dance#password8#", REJECT),
                arguments("O".repeat(300) + "#2025-03-04#04:00#" + "D".repeat(1027) + "#password9#", "Accept#5#"),
                arguments("O".repeat(300) + "#2025-05-04#05:00#" + "D".repeat(1027) + "#password10#", REJECT),
                arguments("Bark#05-04-2025#05:00#Ping#password11#", REJECT),
                arguments("Mouse#2025-05-04#05#Squeak#password12#", REJECT),
                arguments("Cat#2025-05-04#05:00#Meow#password13#", "Accept#6#")
        );
    }

    @ParameterizedTest
    @MethodSource
    void testInteraction(String send, String expected) throws IOException {
        send(send, out);
        String response = readAllChars();
        assertTrue(response.startsWith(expected), "Expected %s but got %s".formatted(expected, response));
        if (!response.equals(expected)) {
            System.err.println("Expected: " + expected + ", got: " + response);
        }
    }

    String readAllChars() throws IOException {
        byte[] buf = clntSock.getInputStream().readAllBytes();
        StringBuilder response = new StringBuilder();
        for (byte b : buf) {
            if (isPrintable((char) b)) {
                response.append((char) b);
            } else {
                response.append("[").append(b).append("]");
            }
        }
        return response.toString();
    }

    @BeforeEach
    void testSetUp() throws IOException {
        clntSock = new Socket(server, port);
        out = new PrintWriter(clntSock.getOutputStream(), true, ENC);
    }

    @AfterEach
    void testTearDown() throws IOException {
        out.close();
        clntSock.close();
    }
}