/************************************************
 * Author: Savitha Samudrala
 * Assignment: Program 4
 * Class: CSC 4610
 ************************************************/


package xperience;

import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * Handles a single client connection and request processing.
 */
public class ClientHandler implements Callable<Void> {

    private static final Logger logger = Logger.getLogger("xperience");
    private static final String DELIM = "#";

    private final Socket socket;
    private final EventStore eventStore;
    private final PasswordList pwList;

    private static final Pattern NAME_PATTERN = Pattern.compile("^.{1,300}$");
    private static final Pattern DATE_PATTERN = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");
    private static final Pattern TIME_PATTERN = Pattern.compile("^([01]\\d|2[0-3]):[0-5]\\d$");
    private static final Pattern DESC_PATTERN = Pattern.compile("^.{1,65535}$");

    public ClientHandler(Socket socket, EventStore eventStore, PasswordList pwList) {
        this.socket = socket;
        this.eventStore = eventStore;
        this.pwList = pwList;
    }

    @Override
    public Void call() {
        logger.info("Handling client at " + socket.getRemoteSocketAddress());

        try (Scanner in = new Scanner(socket.getInputStream(), StandardCharsets.US_ASCII);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.US_ASCII)) {

            in.useDelimiter(DELIM);
            processRequest(in, out);

        } catch (Exception ex) {
            logger.warning("Client communication failed: " + ex.getMessage());
        }

        return null;
    }

    private void processRequest(Scanner in, PrintWriter out) {
        if (!in.hasNext()) {
            reject(out, "Missing password");
            return;
        }
        String password = in.next().trim();
        if (!pwList.use(password)) {
            reject(out, "Invalid or reused password");
            return;
        }

        String name = readAndValidateField(in, out, "event name", NAME_PATTERN);
        if (name == null || eventStore.getEvent(name) != null) {
            reject(out, "Event name exists or is invalid");
            return;
        }

        String date = readAndValidateField(in, out, "date", DATE_PATTERN);
        if (date == null) return;

        String time = readAndValidateField(in, out, "time", TIME_PATTERN);
        if (time == null) return;

        String description = readAndValidateField(in, out, "description", DESC_PATTERN);
        if (description == null) return;

        Event event = new Event(name, date, time, description);
        eventStore.addEvent(event);
        logger.info("Accepted: Event '" + name + "' added successfully");
        out.write("Accept#" + eventStore.getEventCount() + "#");
    }

    private String readAndValidateField(Scanner in, PrintWriter out, String fieldName, Pattern pattern) {
        if (!in.hasNext()) {
            reject(out, "Missing " + fieldName);
            return null;
        }
        String value = in.next().trim();
        if (!pattern.matcher(value).matches()) {
            reject(out, "Invalid format for " + fieldName + " [" + value + "]");
            return null;
        }
        return value;
    }

    private void reject(PrintWriter out, String reason) {
        logger.warning("Rejecting: " + reason);
        out.write("Reject#");
    }
} 
