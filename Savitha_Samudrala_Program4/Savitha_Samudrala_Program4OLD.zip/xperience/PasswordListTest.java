package xperience;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PasswordListTest {

    private Path tempPasswordFile;

    @BeforeEach
    void setUp() throws IOException {
        tempPasswordFile = Files.createTempFile("passwords", ".txt");
        Files.write(tempPasswordFile, List.of("abc", "def", "ghi"));
    }

    @Test
    void testUseValidPassword() throws IOException {
        PasswordList pwList = new PasswordList(tempPasswordFile.toString());
        assertTrue(pwList.use("abc"));
    }

    @Test
    void testUseInvalidPassword() throws IOException {
        PasswordList pwList = new PasswordList(tempPasswordFile.toString());
        assertFalse(pwList.use("xyz"));
    }

    @Test
    void testUseSamePasswordTwice() throws IOException {
        PasswordList pwList = new PasswordList(tempPasswordFile.toString());
        assertTrue(pwList.use("def"));
        assertFalse(pwList.use("def"));
    }
} 
