-- Drop database if it exists
DROP DATABASE IF EXISTS event_db;
CREATE DATABASE Samudrala;
USE Samudrala;

-- Create the Event table
CREATE TABLE Event (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(300) NOT NULL UNIQUE,  -- Max 300 characters, must be unique
    event_date DATE NOT NULL,           -- YYYY-MM-DD format
    event_time TIME NOT NULL,           -- HH:MM 24-hour format
    description TEXT NOT NULL CHECK (CHAR_LENGTH(description) BETWEEN 1 AND 65535)  -- 1-65,535 characters
);

-- Drop user if they already exist
DROP USER IF EXISTS 'event_admin'@'localhost';
DROP USER IF EXISTS 'event_user'@'10.0.2.%';

-- Create an admin user with full privileges
CREATE USER 'event_admin'@'localhost' IDENTIFIED BY 'pass';
GRANT ALL PRIVILEGES ON event_db.* TO 'event_admin'@'localhost';

-- Create a user with read/write access
CREATE USER 'event_user'@'192.168.56.1' IDENTIFIED BY 'user';
GRANT SELECT, INSERT ON event_db.Event TO 'event_user'@'192.168.56.1';

-- Apply the privilege changes
FLUSH PRIVILEGES;
